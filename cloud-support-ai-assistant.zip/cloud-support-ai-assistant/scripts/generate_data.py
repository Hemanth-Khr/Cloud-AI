"""Generate a synthetic labelled dataset of cloud support tickets.

The tickets are assembled from realistic phrase templates so the classifier
has something to learn from. This is *synthetic* training data (clearly stated
in the README) - swap in real/anonymised tickets to improve accuracy.

Usage:
    python scripts/generate_data.py            # writes data/tickets.csv
"""
from __future__ import annotations

import csv
import random
from pathlib import Path

random.seed(42)

# category -> (symptom phrases, context phrases)
CATEGORIES: dict[str, dict[str, list[str]]] = {
    "compute": {
        "symptoms": [
            "my EC2 instance is stuck in pending state",
            "cannot SSH into my EC2 instance, connection timed out",
            "instance failed status checks 1/2 checks passed",
            "EC2 instance keeps rebooting and becomes unreachable",
            "high CPU utilization on my instance, application is slow",
            "auto scaling group is not launching new instances",
            "lambda function timing out after 3 seconds",
            "lambda function throws out of memory error",
            "instance terminated immediately after launch, insufficient capacity",
            "unable to resize the instance type, stop and start fails",
            "ECS task keeps stopping with essential container exited",
            "EBS volume attached but not visible inside the linux server",
        ],
        "context": [
            "in us-east-1",
            "in ap-south-1 region",
            "since this morning",
            "after the latest deployment",
            "for our staging server",
            "on our production web server",
        ],
    },
    "storage": {
        "symptoms": [
            "S3 bucket returns 403 access denied when uploading objects",
            "cannot delete S3 bucket because it is not empty",
            "S3 static website hosting shows 404 not found",
            "need to recover an accidentally deleted S3 object",
            "S3 upload is very slow for large files",
            "bucket policy blocks public read, how to fix",
            "EBS snapshot stuck at 99 percent",
            "EFS mount fails with connection timed out",
            "S3 lifecycle rule is not transitioning objects to Glacier",
            "cross region replication is not copying new objects",
            "presigned URL expired immediately",
            "CORS error when browser uploads to S3",
        ],
        "context": [
            "for our backup bucket",
            "in eu-west-1",
            "since yesterday",
            "after enabling versioning",
            "for the data lake bucket",
            "from our mobile application",
        ],
    },
    "networking": {
        "symptoms": [
            "cannot reach the internet from private subnet instances",
            "VPC peering connection is active but traffic is not flowing",
            "security group rule added but port 443 is still blocked",
            "route 53 domain not resolving to load balancer",
            "application load balancer returns 502 bad gateway",
            "load balancer health checks failing for all targets",
            "NAT gateway not working, no outbound connectivity",
            "DNS propagation taking too long for my domain",
            "VPN tunnel is down between on premises and VPC",
            "network ACL denying return traffic",
            "high latency between two availability zones",
            "elastic IP not associated, website unreachable",
        ],
        "context": [
            "in our production VPC",
            "after changing route tables",
            "since the maintenance window",
            "for the new subnet",
            "in us-west-2",
            "after migrating the domain",
        ],
    },
    "iam_security": {
        "symptoms": [
            "IAM user gets access denied when calling the API",
            "AssumeRole fails with not authorized to perform sts AssumeRole",
            "lost MFA device and cannot log in to the console",
            "need to rotate leaked access keys urgently",
            "IAM policy simulator shows allow but request is denied",
            "cannot create IAM role, permission boundary blocks it",
            "unauthorized operation error when launching instances",
            "root account suspicious login detected",
            "service control policy denies the action in our organization",
            "KMS key access denied when decrypting data",
            "security hub shows critical findings for public resources",
            "cross account role trust policy not working",
        ],
        "context": [
            "for our developer team",
            "since this morning",
            "in the production account",
            "after policy update",
            "for a new joiner",
            "in the sandbox account",
        ],
    },
    "billing": {
        "symptoms": [
            "unexpected charges on my monthly invoice",
            "bill is much higher than last month, need cost breakdown",
            "free tier usage exceeded and I was charged",
            "how to set up budget alerts to avoid overspending",
            "need a refund for charges caused by a misconfiguration",
            "data transfer costs are very high this month",
            "cannot update credit card payment method",
            "reserved instance discount not applied to my bill",
            "cost explorer shows charges for a service I never used",
            "savings plan purchase is not reflected in billing",
            "invoice missing tax information, need GST invoice",
            "account suspended due to unpaid bill",
        ],
        "context": [
            "for this month",
            "for last quarter",
            "on my personal account",
            "for the company account",
            "please advise",
            "this is urgent for finance",
        ],
    },
    "database": {
        "symptoms": [
            "RDS instance running out of storage space",
            "cannot connect to RDS database, connection refused",
            "RDS failover took longer than expected",
            "database CPU at 100 percent, queries are slow",
            "read replica lag is increasing continuously",
            "DynamoDB throttling with provisioned throughput exceeded",
            "need to restore RDS from a snapshot to a point in time",
            "too many connections error on the mysql database",
            "aurora cluster endpoint not reachable from application",
            "RDS parameter group change requires reboot, how to apply",
            "database backup retention period is not working",
            "elasticache redis node is evicting keys unexpectedly",
        ],
        "context": [
            "in production",
            "since last night",
            "after a traffic spike",
            "in us-east-2",
            "for the reporting database",
            "after the engine upgrade",
        ],
    },
    "monitoring": {
        "symptoms": [
            "CloudWatch alarm stuck in insufficient data state",
            "not receiving SNS email notifications for alarms",
            "CloudWatch agent not sending memory metrics",
            "CloudTrail logs are missing for some API calls",
            "need to set up log insights query for error rates",
            "metric filter does not match any log events",
            "custom dashboard widgets show no data",
            "alarm triggered but no action was executed",
            "log group retention is set to never expire, cost concern",
            "X-Ray traces not appearing for my lambda",
            "EventBridge rule not triggering the target",
            "need to enable detailed monitoring for instances",
        ],
        "context": [
            "for our application",
            "since yesterday",
            "in the production account",
            "after enabling the agent",
            "for the api gateway",
            "in ap-southeast-1",
        ],
    },
}

OPENERS = ["", "Hi team, ", "Hello support, ", "Urgent: ", "Please help. ", "Need assistance: "]
CLOSERS = ["", " Please help.", " Any guidance appreciated.", " Thanks in advance.", " Kindly advise."]

SEVERITY_PHRASES = {
    "critical": [
        "Production is completely down and customers are impacted.",
        "Entire site is down, revenue loss every minute.",
        "Possible security breach, data may be exposed.",
    ],
    "high": [
        "Major feature is not working for many users.",
        "This is blocking our release today.",
        "Service is degraded and users are complaining.",
    ],
    "medium": [
        "Workaround exists but it is inconvenient.",
        "Affecting only the staging environment.",
        "",
    ],
    "low": [
        "Just a general question, no impact.",
        "Not urgent, asking for best practice.",
        "Documentation clarification needed.",
    ],
}


def make_ticket(category: str) -> dict[str, str]:
    spec = CATEGORIES[category]
    symptom = random.choice(spec["symptoms"])
    ctx = random.choice(spec["context"])
    severity = random.choices(
        list(SEVERITY_PHRASES), weights=[2, 4, 5, 3], k=1
    )[0]
    sev_text = random.choice(SEVERITY_PHRASES[severity])
    text = f"{random.choice(OPENERS)}{symptom} {ctx}. {sev_text}{random.choice(CLOSERS)}"
    return {"text": " ".join(text.split()), "category": category, "priority": severity}


def main() -> None:
    rows: list[dict[str, str]] = []
    for category in CATEGORIES:
        for _ in range(120):
            rows.append(make_ticket(category))
    random.shuffle(rows)

    out = Path(__file__).resolve().parent.parent / "data" / "tickets.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["text", "category", "priority"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} tickets to {out}")


if __name__ == "__main__":
    main()
