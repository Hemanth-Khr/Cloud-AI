"""Train and evaluate the ticket classifier.

Usage (from the repository root):
    python scripts/train.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.classifier import train  # noqa: E402
from app.config import MODEL_PATH  # noqa: E402


def main() -> None:
    metrics = train()
    print(f"Trained on {metrics['n_train']} synthetic tickets, saved to {MODEL_PATH}")
    print(f"Template hold-out accuracy : {metrics['template_holdout_accuracy']:.1%}  (optimistic - same templates)")
    if "handwritten_eval_accuracy" in metrics:
        print(
            f"Hand-written eval accuracy : {metrics['handwritten_eval_accuracy']:.1%} "
            f"on {metrics['handwritten_eval_n']} unseen tickets  (the number to trust)"
        )
        print("\nPer-class F1 on hand-written set:")
        for label, row in metrics["handwritten_eval_report"].items():
            if isinstance(row, dict) and label not in {"macro avg", "weighted avg"}:
                print(f"  {label:<14} f1={row['f1-score']:.2f}  support={int(row['support'])}")


if __name__ == "__main__":
    main()
