# Storage Troubleshooting: S3, EBS and EFS

**Category:** storage

## Symptoms
- S3 returns 403 AccessDenied
- Static website shows 403 or 404
- Browser upload blocked by CORS
- Deleted objects, replication or lifecycle rules not working
- EBS volume not visible, EFS mount fails

## Troubleshooting steps

### S3 AccessDenied (403) on upload, download or list
1. Identify the caller with `aws sts get-caller-identity`.
2. Check the **IAM policy** allows the needed s3 actions on both the bucket ARN and `bucket/*`.
3. Review the **bucket policy** for an explicit Deny; an explicit deny always wins.
4. Check **S3 Block Public Access** (bucket and account level) and any SCPs in AWS Organizations.
5. For SSE-KMS objects, confirm the caller has `kms:Decrypt` and `kms:GenerateDataKey` on the key.
6. If another account uploaded the objects, use **Object Ownership: bucket owner enforced**.

### S3 static website shows 403 or 404
1. Use the **website endpoint**, not the REST endpoint, and confirm the index document is configured.
2. Check the object key exactly (keys are case-sensitive).
3. For public read, turn off Block Public Access for the bucket and add a bucket policy allowing `s3:GetObject`, or serve it privately through CloudFront with Origin Access Control.
4. Remember that without `s3:ListBucket` permission a missing key returns 403 instead of 404.

### Browser upload fails with a CORS error or a presigned URL expires
1. Add a **CORS configuration** on the bucket with the correct allowed origins, methods and headers.
2. Expose the ETag header if the client needs it for multipart uploads.
3. For presigned URLs, use the same HTTP method and Content-Type that was signed; a URL signed with temporary credentials expires when those credentials expire.
4. Open the browser network tab and read the status of the preflight OPTIONS request.

### Recover deleted objects, replication or lifecycle not working
1. With **versioning** enabled a delete only adds a delete marker; list object versions and remove the delete marker to restore the object.
2. Without versioning deleted objects cannot be recovered, so enable versioning (and consider MFA delete) and keep backups.
3. **Replication** needs versioning on both buckets and an IAM replication role, and it copies only objects created after the rule exists (use S3 Batch Replication for older ones).
4. **Lifecycle** rules run asynchronously about once a day; check the prefix and tag filters and the minimum days or object size for the target storage class.

### Slow S3 uploads of large files
1. Use **multipart upload** and parallelise the parts (the AWS CLI and SDK transfer managers do this).
2. Consider **S3 Transfer Acceleration** for long-distance uploads and keep the bucket in a Region close to the clients.
3. Check the client network bandwidth and any proxy in the path.

### EBS volume not visible or EFS mount fails
1. For a new EBS volume run `lsblk`, create a file system with mkfs if needed, then mount it and add it to fstab with the nofail option.
2. An EBS snapshot sitting near 99 percent is usually finishing its last blocks; large volumes can take hours, so check progress before retrying.
3. For EFS, make sure a **mount target** exists in the instance's Availability Zone and its security group allows NFS TCP 2049 from the instance.
4. Install `amazon-efs-utils` and mount with the EFS helper (TLS optional).

## Escalate when
Access is still denied after the policy simulator shows allow, or an SCP, VPC endpoint policy or Organizations policy may be involved.
