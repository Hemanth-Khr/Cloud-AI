# Monitoring Troubleshooting: CloudWatch, CloudTrail and EventBridge

**Category:** monitoring

## Symptoms
- Alarm stuck in INSUFFICIENT_DATA
- Alarm fires but no email or action
- CloudWatch agent not sending memory or disk metrics
- Metric filters, Logs Insights or X-Ray return nothing
- CloudTrail events missing, EventBridge rule not triggering

## Troubleshooting steps

### CloudWatch alarm stuck in INSUFFICIENT_DATA
1. Confirm the metric is actually being published: open it in the Metrics console with the **same namespace and dimensions** as the alarm.
2. The alarm period must not be shorter than the metric's publish interval (basic monitoring publishes every 5 minutes).
3. Set **treat missing data** to the behaviour you want (notBreaching, ignore, breaching).
4. If an instance was replaced, the InstanceId dimension has changed and the alarm points at the old one.

### Alarm fires but no email or action is executed
1. The **SNS subscription** must be in *Confirmed* state; check spam for the confirmation email.
2. The SNS topic access policy must allow `cloudwatch.amazonaws.com` to publish, and a KMS-encrypted topic needs a key policy that allows CloudWatch.
3. Check alarm actions are enabled and attached to the ALARM state.
4. Turn on SNS delivery status logging to see failed deliveries.

### CloudWatch agent not sending memory or disk metrics
1. The instance role needs the **CloudWatchAgentServerPolicy** managed policy.
2. Check the agent is running with `systemctl status amazon-cloudwatch-agent` and read its log file.
3. Make sure the agent configuration includes mem_used_percent or disk metrics and reload it with fetch-config.
4. Look for the metrics under the **CWAgent** namespace.

### Logs Insights, metric filters, log retention and X-Ray
1. A **metric filter** only matches events ingested after it was created; test the pattern before saving.
2. In **Logs Insights** pick the right log group and time range, for example `stats count(*) by bin(5m)` for error rates.
3. Set a **retention period** on log groups to control cost; the default is never expire.
4. For X-Ray enable active tracing on the Lambda function and allow `xray:PutTraceSegments` in its role.

### CloudTrail events missing or EventBridge rule not triggering
1. Check the trail is **multi-Region**, logging is on and management events are selected; events can take around 15 minutes to appear.
2. For EventBridge confirm the **event pattern** matches the event, the rule is on the right event bus and Region, and use a test event to verify.
3. Check the target permissions: a Lambda target needs a resource policy that allows `events.amazonaws.com`.
4. For scheduled rules double-check the cron or rate expression (it runs in UTC).

## Escalate when
Metrics are published and the alarm configuration is correct but the alarm still does not evaluate as expected.
