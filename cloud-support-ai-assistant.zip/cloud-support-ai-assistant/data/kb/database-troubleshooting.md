# Database Troubleshooting: RDS, Aurora, DynamoDB and ElastiCache

**Category:** database

## Symptoms
- Cannot connect (connection refused or timed out)
- Too many connections
- High CPU, slow queries, replica lag, storage full
- DynamoDB throttling, ElastiCache evictions

## Troubleshooting steps

### Cannot connect to the database (connection refused or timeout)
1. Confirm the **endpoint and port** and that the DB security group allows the client's security group or CIDR on the database port.
2. If connecting from outside the VPC, the instance must be **publicly accessible** in a public subnet; otherwise use a bastion, an SSM tunnel or a VPN.
3. Check the DB instance status is *available* and review network ACLs.
4. Verify credentials, IAM database authentication and any SSL requirement.
5. For Aurora use the **cluster (writer) endpoint** for writes and the reader endpoint for reads.

### Too many connections error
1. Check `max_connections` in the **parameter group**; the default depends on instance memory.
2. Add application **connection pooling** or use **RDS Proxy**.
3. Find idle or long-running sessions (SHOW PROCESSLIST or pg_stat_activity) and set idle timeouts.
4. Scale up the instance class if the limit is genuinely too low.

### High CPU or slow queries
1. Turn on **Performance Insights** and review the top SQL by load.
2. Read the slow query log, run EXPLAIN and add missing indexes.
3. Check for traffic spikes or connection storms and add **read replicas** for read-heavy load.
4. On burstable db.t instances check the CPU credit balance.

### Storage full or replica lag increasing
1. Watch the **FreeStorageSpace** metric, enable **storage autoscaling** or increase the allocated storage, and remove old data or binary logs.
2. For **replica lag**, check the ReplicaLag metric and look for long transactions or heavy write bursts on the primary.
3. Give the replica the same or a larger instance class than the primary.

### Restore, backups and parameter group changes
1. **Point-in-time restore** always creates a new instance; update the application endpoint afterwards.
2. The backup retention period must be greater than zero for point-in-time restore; keep a final snapshot before deleting an instance.
3. Dynamic parameters apply immediately; **static parameters need a reboot** (status pending-reboot).

### DynamoDB throttling (ProvisionedThroughputExceeded)
1. Compare ConsumedCapacity with provisioned capacity and read the ThrottledRequests metric.
2. Switch to **on-demand** mode or enable auto scaling, and fix hot partition keys.
3. Use exponential backoff with jitter (the AWS SDKs retry automatically).

### ElastiCache Redis evicting keys
1. Check the Evictions and memory usage metrics.
2. Review the **maxmemory-policy** and set TTLs on keys.
3. Scale up the node type or add shards.

## Escalate when
A Multi-AZ failover does not complete, storage is stuck in storage-full, or the instance is stuck in a modifying state.
