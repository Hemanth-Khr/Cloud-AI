# Networking Troubleshooting: VPC, NAT, Load Balancers, DNS, Peering and VPN

**Category:** networking

## Symptoms
- Private subnet instances have no internet access
- ALB returns 502, 503 or 504, or targets are unhealthy
- Domain does not resolve
- VPC peering or VPN traffic is not flowing
- A port is still blocked after adding a security group rule

## Troubleshooting steps

### Private subnet instances have no internet access (NAT gateway)
1. Check the private subnet **route table** has `0.0.0.0/0` pointing to the NAT Gateway.
2. The NAT Gateway must be in a **public subnet** that routes `0.0.0.0/0` to an Internet Gateway, and it needs an Elastic IP.
3. Security groups are stateful but **network ACLs are stateless**; allow the ephemeral return ports explicitly.
4. Check the NAT Gateway state and the CloudWatch metric ErrorPortAllocation.
5. Use **VPC Reachability Analyzer** and **VPC Flow Logs** to see where packets are dropped.

### Load balancer returns 502 or 504, or health checks fail (ALB)
1. For unhealthy targets verify the **health check** path, port and expected status code (matcher).
2. The target security group must allow traffic from the **ALB security group** on the target port.
3. A **502 Bad Gateway** means the target closed the connection or sent a malformed response; read the application logs and set the app keep-alive timeout higher than the ALB idle timeout (60 seconds by default).
4. A **503** means no healthy targets are registered; a **504** means the target did not answer within the idle timeout, so fix the slow request or raise the timeout.
5. Compare HTTPCode_ELB_5XX with HTTPCode_Target_5XX in CloudWatch and enable ALB access logs.

### Route 53 or DNS name is not resolving
1. The registrar's **name servers** must match the NS records of the Route 53 hosted zone.
2. Use an **Alias A record** for an ALB, CloudFront or S3 website; a CNAME cannot be used at the zone apex.
3. Wait for the old TTL to expire and test with `dig` against the authoritative name server and against 8.8.8.8.
4. For a private hosted zone, associate it with the VPC and enable DNS support and DNS hostnames on the VPC.

### VPC peering or VPN traffic is not flowing
1. For **peering**, make sure the request is accepted, add a route to the peer CIDR in **both** route tables, and avoid overlapping CIDRs; peering is not transitive.
2. Allow the peer CIDR (or reference the peer security group) in security groups and network ACLs.
3. For a **VPN tunnel that is down**, check the tunnel status and that the IKE/IPsec settings match the customer gateway device.
4. Enable route propagation on the route table and make sure the on-premises firewall allows UDP 500, UDP 4500 and ESP.
5. Use Reachability Analyzer and the CloudWatch TunnelState metric.

### Security group rule added but the port is still blocked
1. Security group rules are allow-only and stateful; confirm the right group is attached to the right network interface.
2. Check network ACLs for an explicit deny and the rule order.
3. Check the OS firewall and that the service listens on the right address with `ss -tlnp`.
4. If the site is unreachable from the internet, confirm an Elastic IP or public IP is associated and the route to the Internet Gateway exists.

## Escalate when
Reachability Analyzer shows a valid path but traffic still fails, or a VPN tunnel flaps on the AWS side.
