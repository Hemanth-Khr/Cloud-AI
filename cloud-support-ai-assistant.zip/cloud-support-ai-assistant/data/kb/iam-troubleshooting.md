# IAM and Security Troubleshooting

**Category:** iam_security

## Symptoms
- "not authorized to perform ..." or AccessDenied errors
- AssumeRole fails, cross-account access broken
- Access keys leaked or suspicious account activity
- Lost or broken MFA device

## Troubleshooting steps

### Access denied or not authorized to perform an action
1. Read the error message: it names the **principal ARN**, the **action** and the **resource**.
2. Remember the evaluation order: explicit Deny, then SCPs, permission boundary, session policy, then identity and resource policies.
3. Use the **IAM Policy Simulator** and search **CloudTrail** for the denied event (errorCode AccessDenied).
4. Check policy **conditions** such as aws:SourceIp, MFA required, resource tags and Region.
5. For KMS, the **key policy** must allow the principal; IAM policies alone are not enough.
6. Grant least privilege: scope actions and resources instead of using wildcards.

### AssumeRole fails or cross-account access does not work
1. The role's **trust policy** must allow the caller's principal (the account or the specific user or role).
2. The caller's identity policy must allow `sts:AssumeRole` on the role ARN; for cross-account access **both sides** are required.
3. Check trust policy conditions such as ExternalId, MFA and the maximum session duration.
4. Look for an SCP or permission boundary on the caller that blocks sts:AssumeRole.
5. Reproduce with `aws sts assume-role` and read the exact error.

### Leaked access keys or suspicious account activity (security incident)
1. **Deactivate the exposed access key immediately**, then delete it after review; do not wait.
2. Review **CloudTrail** for everything the key did: new IAM users or roles, EC2 instances, unusual Regions.
3. Rotate all affected credentials and revoke active sessions of any role the key could assume.
4. Remove the key from the repository history (a private repo is still exposed) and enable **GuardDuty** and **Security Hub**.
5. For a suspicious **root account** login, change the password, make sure MFA is enabled, review contacts and open an AWS Support case.

### Lost or broken MFA device
1. For an **IAM user**, an administrator deactivates or resyncs the MFA device in IAM, then the user registers a new one.
2. For the **root user**, use the "Troubleshoot MFA" option on the sign-in page, which verifies the account email and phone number.
3. If codes are rejected, fix the clock on the device and resync.
4. Register more than one MFA device for important users in future.

## Escalate when
A compromise is suspected, API activity looks unusual, or the root account shows a suspicious login. Treat these as security incidents.
