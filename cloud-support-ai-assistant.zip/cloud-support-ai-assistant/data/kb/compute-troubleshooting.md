# Compute Troubleshooting: EC2, Auto Scaling and Lambda

**Category:** compute

## Symptoms
- SSH or RDP times out, instance status checks fail
- Instance stuck in pending or terminates right after launch
- High CPU and a slow application
- Auto Scaling group is not adding instances
- Lambda function times out or runs out of memory

## Troubleshooting steps

### Cannot SSH or RDP into an EC2 instance (connection timed out)
1. Check the **instance status checks** in the EC2 console. A system check failure is an AWS host problem (stop and start to move hosts); an instance check failure is an OS-level problem (read the console output or screenshot).
2. Verify the **security group** allows inbound TCP 22 (Linux) or 3389 (Windows) from your IP address.
3. Verify the **network ACL** allows inbound traffic and the ephemeral return ports 1024-65535.
4. Confirm the subnet **route table** has a route to an Internet Gateway and the instance has a public IP or Elastic IP.
5. Check the OS firewall (iptables, ufw or Windows Firewall) and that the SSH daemon is running.
6. Use **EC2 Instance Connect** or **Session Manager (SSM)** as an alternative access path.
7. If the OS is broken, stop the instance, detach the root EBS volume, attach it to a rescue instance, fix the SSH or fstab configuration, then reattach it.

### Instance stuck in pending or terminates immediately after launch
1. Read the **state transition reason** (for example Server.InsufficientInstanceCapacity or Client.VolumeLimitExceeded) in the instance details.
2. For InsufficientInstanceCapacity, retry later, choose another Availability Zone or instance type, or use a capacity reservation.
3. For encrypted AMIs or volumes, make sure the KMS key policy allows the account and EC2 to use the key.
4. Check **Service Quotas** for the vCPU limit of that instance family in the Region.

### High CPU or the application is slow
1. Review CloudWatch **CPUUtilization**; on burstable T instances also check **CPUCreditBalance**, because an empty balance throttles the CPU.
2. Log in and use top or htop to find the busy process.
3. Right-size the instance type or move to a non-burstable family; add Auto Scaling for load spikes.
4. Enable detailed monitoring for 1-minute metrics.

### Auto Scaling group is not launching new instances
1. Open the group's **Activity history** and read the failure reason.
2. Validate the launch template: the AMI exists in this Region, the key pair, security group and instance profile are valid.
3. Check desired and maximum capacity, the scaling policy and whether the CloudWatch alarm driving it is actually in ALARM.
4. Confirm the selected subnets have free IP addresses and capacity, and that vCPU quotas are not exhausted.

### Lambda function times out or runs out of memory
1. Open the CloudWatch Logs **REPORT** line and compare Duration and Max Memory Used with the configured limits.
2. Raise the timeout (up to 15 minutes) and the memory size; CPU scales with memory.
3. If the function is attached to a VPC, it needs a NAT gateway or VPC endpoints to reach the internet or AWS services, otherwise calls hang until the timeout.
4. Add client timeouts and retries for downstream calls and check reserved concurrency and throttles.

### ECS task keeps stopping
1. Read the stopped task's **stoppedReason** and container exit code; code 137 means the container was killed for exceeding its memory limit.
2. Raise the task or container memory hard limit.
3. Check the container logs in CloudWatch Logs and the health check command.

## Escalate when
System status checks fail repeatedly after a stop and start, the console output shows a kernel panic, or capacity errors persist across several Availability Zones.
