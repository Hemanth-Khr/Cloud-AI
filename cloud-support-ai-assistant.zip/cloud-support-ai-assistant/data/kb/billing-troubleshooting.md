# Billing and Cost Troubleshooting

**Category:** billing

## Symptoms
- Bill is higher than expected
- Charged after the free tier
- Reserved Instance or Savings Plan discount not applied
- Payment method, invoice or account suspension problems

## Troubleshooting steps

### Unexpected charges or a bill higher than usual
1. Open **Cost Explorer** and group by Service, then by Usage Type and Region to find what drove the cost.
2. Look for forgotten resources: idle EC2 instances, unattached EBS volumes, unused Elastic IPs, NAT Gateways, load balancers and old snapshots.
3. Check **data transfer**: internet egress and cross-Region or cross-AZ traffic are billed; VPC endpoints and CloudFront can reduce it.
4. Set up **AWS Budgets** alerts at 50, 80 and 100 percent and turn on **Cost Anomaly Detection** and cost allocation tags.

### Free tier exceeded or a refund is needed
1. Review the **Free Tier** usage page; limits are per service and per month, and some offers expire after 12 months.
2. Stop or terminate the resources that are still generating charges.
3. For a refund caused by a misconfiguration, open a billing support case with the resource IDs and the timeline; credits are at AWS's discretion.

### Reserved Instance or Savings Plan discount not applied
1. Verify the **scope** matches the usage: Region or Availability Zone, instance family, tenancy, platform and account.
2. Check the Savings Plans utilization and coverage reports to see how much of the commitment is used.
3. Confirm the purchase is active (the start date has passed); discounts appear as amortized cost in Cost Explorer.

### Payment method, tax invoice or account suspension
1. Update the card in **Billing, Payment preferences**, check the card has not expired and retry the payment.
2. To receive tax invoices add your tax registration number (for example GST) in the Billing tax settings, then download invoices from the Bills page.
3. For a suspension caused by an unpaid bill, pay the outstanding balance and open a support case if access is not restored.

## Escalate when
Charges are for resources the customer cannot find, or fraud or an account compromise is suspected.
