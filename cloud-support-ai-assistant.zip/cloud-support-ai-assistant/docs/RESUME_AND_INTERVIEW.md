# Resume, GitHub and Interview Guide

Delete this file (or keep it out of the public repo) once you have copied what you need.

## 1. Resume entry

**Cloud Support Copilot: AI-Assisted Ticket Triage** | Python, FastAPI, scikit-learn, Docker, GitHub Actions | [GitHub link]

- Built a REST API that triages cloud support tickets: classifies them into 7 categories (compute, storage, networking, IAM/security, billing, database, monitoring) with **92.9% accuracy on 42 unseen hand-written tickets** (TF-IDF + Logistic Regression).
- Designed a RAG-style retrieval layer over 7 AWS runbooks (**37 troubleshooting scenarios, 152 steps**) using scenario-level chunking, cosine similarity and category-aware boosting to return the exact fix steps for a ticket.
- Implemented an explainable priority engine and a log analyzer for **13 common failure signatures** (Lambda timeouts, OOM kills, AccessDenied, ALB 5xx, throttling, DNS/TLS errors), with automatic redaction of AWS keys and passwords.
- Added optional Claude integration to polish drafted replies with graceful fallback, plus Docker packaging, GitHub Actions CI and **57 automated pytest tests**.

Shorter version (2 lines): *Python/FastAPI service that classifies and prioritises AWS support tickets, retrieves runbook steps and analyses logs to draft first responses; 92.9% category accuracy on an independent test set, 57 tests, Docker + CI.*

## 2. Publish it on GitHub

```bash
cd cloud-support-ai-assistant
git init && git add . && git commit -m "Cloud Support Copilot: AI-assisted ticket triage"
git branch -M main
git remote add origin https://github.com/<your-username>/cloud-support-ai-assistant.git
git push -u origin main
```

- **Repo name:** `cloud-support-ai-assistant`
- **Description:** AI-assisted cloud support ticket triage: classification, priority, runbook retrieval, log analysis, draft replies (FastAPI + scikit-learn)
- **Topics:** `cloud-support`, `aws`, `fastapi`, `machine-learning`, `rag`, `scikit-learn`, `devops`, `python`
- Replace `<your-username>` in the README badge and clone URL, pin the repo on your profile, and add two screenshots (the `/docs` Swagger page and the CLI output) to the README.

## 3. Be honest about it (this protects you in interviews)

- The training tickets are **synthetic** and the knowledge base was **written by you for this project**. Say so. The README already explains it.
- Quote the **92.9% on hand-written tickets**, not the 100% template hold-out.
- Before you list **Docker** on your resume, run `docker build` and `docker run` once yourself and confirm `/health` responds.
- Only claim AWS skills you can demonstrate. If you deploy it (section 5), you can say so truthfully.

## 4. Thirty-second pitch

"Support engineers lose a lot of time on first-response work: reading the ticket, deciding the category and priority, finding the right runbook and asking the customer for details. I built a service that does that automatically for AWS tickets. It classifies the ticket, scores priority with explainable rules, retrieves the matching troubleshooting scenario from a runbook knowledge base, scans pasted logs for known failures and drafts the reply. An LLM can optionally polish the wording, but the core works without one."

## 5. Questions you should be ready for

1. **Why TF-IDF and Logistic Regression instead of an LLM?** Fast, explainable, no API cost or key, trains in under a second; the LLM is optional and only polishes wording.
2. **Your data is synthetic. How do you know it works?** I do not over-trust it: the random split scores 100% because it shares templates, so I wrote 42 independent tickets and report 92.9% on those. Next step is real, anonymised tickets.
3. **What does RAG mean here and where is it in your project?** Retrieval-augmented generation: retrieve relevant knowledge, then generate the answer from it. Retrieval is the runbook search; generation is the template reply or, optionally, Claude constrained to the retrieved steps.
4. **Why chunk runbooks by scenario?** Page-level retrieval returned generic steps (NAT steps for an ALB 502 ticket). Scenario chunks return the steps for the actual problem.
5. **Why is priority rule-based?** Engineers need to see why a ticket was escalated; rules are reviewable and tunable.
6. **What happens when the model is unsure?** Below 0.40 confidence the ticket is flagged for human review and the reply says it is being routed.
7. **How do you handle sensitive data?** Keys and passwords are redacted from echoed log lines, replies and LLM prompts, and ticket text is treated as untrusted data in the prompt.
8. **Walk me through troubleshooting an ALB 502.** Check target health and health check settings, target security group allows the ALB, app keep-alive vs. ALB idle timeout, then compare ELB 5xx with target 5xx metrics. (This is runbook content you can explain in detail.)
9. **How would you improve it?** Embeddings for retrieval, real labelled tickets, a feedback loop for corrections, more providers (Azure, GCP), deployment on AWS with monitoring.
10. **What would break at scale?** In-memory TF-IDF index and a single process; move to a vector store, run multiple workers and add request logging and metrics.

## 6. Level-up checklist for cloud support roles

These make the project stronger because the role is *cloud* support, not only Python:

- [ ] Deploy it on AWS (EC2, App Runner or ECS Fargate), put the logs in CloudWatch and attach an IAM role instead of keys. Add a screenshot and a "Deployed on AWS" section to the README.
- [ ] Use the runbooks as study material: be able to reproduce every scenario in a free-tier account (break a security group, break a NAT route, trigger an alarm).
- [ ] Work towards **AWS Certified Cloud Practitioner**, then **Solutions Architect Associate**.
- [ ] Add 5-10 runbooks of your own from issues you actually reproduced, and mention that in the README.
- [ ] Write a short blog post or README section: "How I troubleshoot an ALB 502".
