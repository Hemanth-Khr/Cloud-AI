"""FastAPI application exposing the triage pipeline.

Run locally:  uvicorn app.main:app --reload
Docs UI:      http://localhost:8000/docs
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from . import __version__
from .log_analyzer import analyze_logs
from .schemas import LogAnalysis, LogRequest, TriageRequest, TriageResponse
from .service import TriageService


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.service = TriageService()
    yield


app = FastAPI(
    title="Cloud Support Copilot",
    description="AI-assisted ticket triage: classify, prioritise, find runbooks, analyse logs, draft replies.",
    version=__version__,
    lifespan=lifespan,
)


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok", "version": __version__}


@app.post("/triage", response_model=TriageResponse, tags=["triage"])
def triage(req: TriageRequest) -> dict:
    return app.state.service.triage(
        description=req.description,
        subject=req.subject,
        logs=req.logs,
        use_llm=req.use_llm,
    )


@app.post("/analyze-logs", response_model=LogAnalysis, tags=["logs"])
def analyze(req: LogRequest) -> dict:
    return analyze_logs(req.logs)


@app.get("/kb", tags=["knowledge-base"])
def list_kb() -> list[dict]:
    return app.state.service.retriever.list_articles()
