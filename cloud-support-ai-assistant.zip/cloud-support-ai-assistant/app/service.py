"""Orchestrates classifier, priority rules, retrieval, log analysis and reply drafting."""
from __future__ import annotations

from typing import Any

from . import config
from .classifier import TicketClassifier
from .log_analyzer import analyze_logs
from .priority import score_priority
from .redact import redact
from .responder import build_draft_reply, polish_with_llm
from .retriever import Retriever


class TriageService:
    def __init__(self) -> None:
        self.classifier = TicketClassifier()
        self.retriever = Retriever()

    def triage(
        self,
        description: str,
        subject: str = "",
        logs: str | None = None,
        use_llm: bool = False,
    ) -> dict[str, Any]:
        text = f"{subject}. {description}".strip(". ")
        prediction = self.classifier.predict(text)
        needs_review = prediction.confidence < config.MIN_CONFIDENCE

        # Logs also count towards priority (e.g. "Connection refused" bursts).
        log_result = analyze_logs(logs) if logs else None
        priority = score_priority(text, prediction.label)

        hits = self.retriever.search(
            text, k=3, category=None if needs_review else prediction.label
        )
        scenario = self.retriever.scenario_for(hits[0].doc_id, text) if hits else None
        steps = scenario.steps[:5] if scenario else []

        findings = log_result["findings"] if log_result else []
        draft = build_draft_reply(
            subject, prediction.label, priority.level, steps, findings, needs_review
        )
        reply, source = draft, "template"
        if use_llm:
            polished = polish_with_llm(draft, text)
            if polished:
                reply, source = polished, "llm"

        return {
            "category": prediction.label,
            "category_label": config.CATEGORY_LABELS.get(prediction.label, prediction.label),
            "confidence": round(prediction.confidence, 3),
            "alternatives": [
                {"category": c, "confidence": round(p, 3)} for c, p in prediction.alternatives
            ],
            "needs_human_review": needs_review,
            "priority": priority.level,
            "priority_reasons": priority.reasons,
            "target_first_response": config.SLA_TARGETS[priority.level],
            "suggested_articles": [
                {
                    "id": h.doc_id,
                    "title": h.title,
                    "category": h.category,
                    "matched_section": h.section,
                    "score": round(h.score, 3),
                }
                for h in hits
            ],
            "matched_scenario": scenario.scenario if scenario else None,
            "suggested_steps": steps,
            "log_analysis": log_result,
            "draft_reply": redact(reply),
            "reply_source": source,
        }
