"""Scan pasted logs for well-known cloud failure signatures."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass

from .redact import redact

MAX_LOG_CHARS = 200_000
SEVERITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1}


@dataclass(frozen=True)
class LogPattern:
    id: str
    regex: str
    severity: str
    category: str
    title: str
    advice: str


PATTERNS: list[LogPattern] = [
    LogPattern(
        "lambda_timeout",
        r"Task timed out after [\d.]+ seconds",
        "high",
        "compute",
        "Lambda function timeout",
        "Increase the function timeout, check downstream latency, and review whether the function is waiting on a VPC resource without a NAT/endpoint.",
    ),
    LogPattern(
        "out_of_memory",
        r"Out of memory|OutOfMemory|oom-killer|Killed process|exit code 137|signal: killed",
        "high",
        "compute",
        "Out-of-memory kill",
        "Raise the memory limit or instance size and look for memory leaks; on ECS check the task memory hard limit.",
    ),
    LogPattern(
        "disk_full",
        r"No space left on device|disk full",
        "high",
        "storage",
        "Disk full",
        "Free space or expand the EBS volume, then grow the partition and file system.",
    ),
    LogPattern(
        "access_denied",
        r"AccessDenied|not authorized to perform|UnauthorizedOperation|AuthFailure|403 Forbidden",
        "high",
        "iam_security",
        "Permission denied",
        "Identify the principal and action in the message, then check IAM policies, bucket/resource policies, SCPs and permission boundaries.",
    ),
    LogPattern(
        "connection_refused",
        r"Connection refused|ECONNREFUSED",
        "high",
        "networking",
        "Connection refused",
        "The target host is reachable but nothing is listening: confirm the service is running on the expected port and that security groups allow it.",
    ),
    LogPattern(
        "gateway_error",
        r"502 Bad Gateway|503 Service Unavailable|504 Gateway Time-?out",
        "high",
        "networking",
        "Load balancer / gateway 5xx error",
        "Check target health, application logs, keep-alive vs. idle timeout, and security group rules between the load balancer and targets.",
    ),
    LogPattern(
        "too_many_connections",
        r"Too many connections|remaining connection slots",
        "high",
        "database",
        "Database connection limit reached",
        "Use connection pooling or RDS Proxy and review max_connections in the parameter group.",
    ),
    LogPattern(
        "tls_certificate",
        r"certificate (has )?expired|x509|SSL(.*)(error|handshake)",
        "high",
        "networking",
        "TLS / certificate problem",
        "Renew or replace the certificate (ACM auto-renews only when DNS/email validation still passes) and verify the chain.",
    ),
    LogPattern(
        "throttling",
        r"Throttl|Rate exceeded|TooManyRequests|ProvisionedThroughputExceeded|\b429\b",
        "medium",
        "general",
        "API throttling",
        "Add retries with exponential backoff and jitter, spread load, and request a quota increase if needed.",
    ),
    LogPattern(
        "capacity",
        r"InsufficientInstanceCapacity|Insufficient capacity",
        "medium",
        "compute",
        "Insufficient capacity",
        "Retry in another Availability Zone or instance type, or use a capacity reservation.",
    ),
    LogPattern(
        "connection_timeout",
        r"Connection timed out|ETIMEDOUT|timed out",
        "medium",
        "networking",
        "Connection timeout",
        "Check security groups, NACLs, route tables and that the destination is reachable from the source subnet.",
    ),
    LogPattern(
        "dns_failure",
        r"Name or service not known|NXDOMAIN|Could not resolve host|ENOTFOUND",
        "medium",
        "networking",
        "DNS resolution failure",
        "Verify the record exists, the hosted zone is correct, VPC DNS resolution/hostnames are enabled and the resolver is reachable.",
    ),
    LogPattern(
        "missing_object",
        r"NoSuchBucket|NoSuchKey",
        "medium",
        "storage",
        "S3 bucket or object not found",
        "Confirm the bucket name, region and object key (keys are case-sensitive).",
    ),
]

_ERROR_LINE = re.compile(r"\b(ERROR|FATAL|CRITICAL|Exception|Traceback)\b")


def analyze_logs(logs: str) -> dict:
    """Return ``{"findings": [...], "error_line_count": n, "lines_scanned": n}``."""
    logs = logs[:MAX_LOG_CHARS]
    lines = logs.splitlines()
    counts: dict[str, int] = {}
    evidence: dict[str, str] = {}
    error_lines = 0

    for line in lines:
        if _ERROR_LINE.search(line):
            error_lines += 1
        for pattern in PATTERNS:
            if re.search(pattern.regex, line, flags=re.I):
                counts[pattern.id] = counts.get(pattern.id, 0) + 1
                evidence.setdefault(pattern.id, redact(line.strip())[:240])

    findings = []
    for pattern in PATTERNS:
        if pattern.id in counts:
            item = asdict(pattern)
            item.pop("regex")
            item["occurrences"] = counts[pattern.id]
            item["example"] = evidence[pattern.id]
            findings.append(item)

    findings.sort(key=lambda f: (SEVERITY_RANK[f["severity"]], f["occurrences"]), reverse=True)
    return {
        "findings": findings,
        "error_line_count": error_lines,
        "lines_scanned": len(lines),
    }
