"""Command-line demo:  python -m app.cli "my EC2 instance is unreachable" [--logs file.log]"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .service import TriageService


def main() -> None:
    parser = argparse.ArgumentParser(description="Triage a cloud support ticket")
    parser.add_argument("description", help="Ticket text")
    parser.add_argument("--subject", default="")
    parser.add_argument("--logs", type=Path, help="Path to a log file to analyse")
    parser.add_argument("--llm", action="store_true", help="Polish reply with Claude (needs ANTHROPIC_API_KEY)")
    parser.add_argument("--json", action="store_true", help="Print raw JSON instead of a summary")
    args = parser.parse_args()

    logs = args.logs.read_text(encoding="utf-8", errors="replace") if args.logs else None
    result = TriageService().triage(args.description, args.subject, logs, use_llm=args.llm)

    if args.json:
        print(json.dumps(result, indent=2))
        return

    print(f"Category : {result['category_label']} (confidence {result['confidence']:.0%})")
    if result["needs_human_review"]:
        print("           ^ low confidence - routed for human review")
    print(f"Priority : {result['priority'].upper()} - {'; '.join(result['priority_reasons'])}")
    print(f"Target   : first response within {result['target_first_response']}")
    print("Articles :")
    for a in result["suggested_articles"]:
        print(f"  - {a['title']} (score {a['score']})")
    print("\n----- Draft reply -----")
    print(result["draft_reply"])


if __name__ == "__main__":
    main()
