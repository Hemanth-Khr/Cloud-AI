"""Central configuration: file locations and tunable thresholds."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
KB_DIR = DATA_DIR / "kb"
TICKETS_CSV = DATA_DIR / "tickets.csv"
EVAL_CSV = DATA_DIR / "eval_tickets.csv"
MODEL_PATH = ROOT / "models" / "ticket_classifier.joblib"

# Below this confidence the ticket is flagged for a human to categorise.
MIN_CONFIDENCE = float(os.getenv("MIN_CONFIDENCE", "0.40"))

# Optional LLM polishing of the drafted reply (off unless a key is set).
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
LLM_TIMEOUT_SECONDS = float(os.getenv("LLM_TIMEOUT_SECONDS", "20"))

CATEGORY_LABELS = {
    "compute": "Compute (EC2 / Lambda / ECS)",
    "storage": "Storage (S3 / EBS / EFS)",
    "networking": "Networking (VPC / ELB / Route 53)",
    "iam_security": "Identity & Security (IAM / KMS)",
    "billing": "Billing & Cost",
    "database": "Database (RDS / DynamoDB)",
    "monitoring": "Monitoring & Logging (CloudWatch / CloudTrail)",
}

# Example first-response targets by priority (illustrative, not a real SLA).
SLA_TARGETS = {
    "critical": "15 minutes",
    "high": "1 hour",
    "medium": "4 hours",
    "low": "1 business day",
}
