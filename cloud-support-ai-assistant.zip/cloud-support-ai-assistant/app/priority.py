"""Explainable, rule-based priority scoring.

Priority is deliberately rule-based rather than a black-box model: support
engineers need to see *why* a ticket was escalated, and the rules are easy to
review and tune.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

CRITICAL_SIGNALS = [
    r"production (is )?(completely |totally )?down",
    r"(site|website|service|app|application) is (completely )?down",
    r"\boutage\b",
    r"security breach|\bbreach\b|compromis|ransomware",
    r"data (may be |was |is )?(exposed|leaked|lost)|data loss",
    r"(pushed|committed|leaked|exposed|posted)\b.{0,30}\b(access|secret) keys?"
    r"|(access|secret) keys?\b.{0,40}\b(leaked|exposed|pushed|committed|public repo)",
    r"suspicious (login|activity)",
    r"revenue loss|customers are impacted|all (users|customers)",
]

HIGH_SIGNALS = [
    r"blocking",
    r"degraded",
    r"not working for (many|all)|many users",
    r"\burgent\b",
    r"deadline|release today|go[- ]live",
    r"unreachable|cannot (access|connect|reach)|can't (access|connect|reach)",
    r"production",
]

LOW_SIGNALS = [
    r"general question",
    r"not urgent",
    r"no impact",
    r"best practice",
    r"documentation",
    r"\bhow (do|can|to)\b.*\b(set up|configure|enable)\b",
]


@dataclass
class PriorityResult:
    level: str
    reasons: list[str]


def _matches(patterns: list[str], text: str) -> list[str]:
    return [m.group(0) for p in patterns if (m := re.search(p, text, flags=re.I))]


def score_priority(text: str, category: str | None = None) -> PriorityResult:
    """Return ``critical`` / ``high`` / ``medium`` / ``low`` with reasons."""
    critical = _matches(CRITICAL_SIGNALS, text)
    if critical:
        return PriorityResult("critical", [f"matched critical signal: '{s}'" for s in critical[:3]])

    low = _matches(LOW_SIGNALS, text)
    if low:
        return PriorityResult("low", [f"matched low-impact signal: '{s}'" for s in low[:3]])

    high = _matches(HIGH_SIGNALS, text)
    if high:
        return PriorityResult("high", [f"matched high-impact signal: '{s}'" for s in high[:3]])

    if category == "iam_security":
        return PriorityResult("high", ["security-related tickets default to high priority"])

    return PriorityResult("medium", ["no urgency or impact signals found"])
