"""Runbook retrieval over the markdown knowledge base (TF-IDF + cosine similarity).

This is the retrieval half of a RAG pipeline. Runbooks are chunked at *scenario*
level: every ``### Scenario`` under "Troubleshooting steps" is its own chunk, so a
ticket about an ALB 502 retrieves the ALB steps rather than a whole networking
page. Documents whose category matches the classifier's prediction get a small
score boost.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

from .config import KB_DIR

CATEGORY_BOOST = 0.10
MIN_SCORE = 0.05
SCENARIO_PREFIX = "Troubleshooting: "


@dataclass
class Chunk:
    doc_id: str
    title: str
    category: str
    section: str
    text: str
    steps: list[str] = field(default_factory=list)

    @property
    def scenario(self) -> str | None:
        return self.section[len(SCENARIO_PREFIX):] if self.steps else None


@dataclass
class Hit:
    doc_id: str
    title: str
    category: str
    section: str
    score: float


def _parse_steps(body: str) -> list[str]:
    raw = re.findall(r"^\s*\d+\.\s+(.*)$", body, flags=re.M)
    return [s.replace("**", "").replace("`", "") for s in raw]


def _load_chunks(kb_dir: Path) -> list[Chunk]:
    chunks: list[Chunk] = []
    for path in sorted(kb_dir.glob("*.md")):
        raw = path.read_text(encoding="utf-8")
        title_match = re.search(r"^#\s+(.+)$", raw, flags=re.M)
        cat_match = re.search(r"\*\*Category:\*\*\s*([\w-]+)", raw)
        title = title_match.group(1).strip() if title_match else path.stem
        category = cat_match.group(1) if cat_match else "general"

        for part in re.split(r"^##\s+", raw, flags=re.M)[1:]:
            heading, _, body = part.partition("\n")
            if heading.strip().lower().startswith("troubleshooting"):
                for sub in re.split(r"^###\s+", body, flags=re.M)[1:]:
                    name, _, sub_body = sub.partition("\n")
                    chunks.append(
                        Chunk(
                            path.stem,
                            title,
                            category,
                            f"{SCENARIO_PREFIX}{name.strip()}",
                            sub_body.strip(),
                            _parse_steps(sub_body),
                        )
                    )
            else:
                chunks.append(Chunk(path.stem, title, category, heading.strip(), body.strip()))
    return chunks


class Retriever:
    def __init__(self, kb_dir: Path = KB_DIR):
        self.chunks = _load_chunks(kb_dir)
        if not self.chunks:
            raise RuntimeError(f"No knowledge-base articles found in {kb_dir}")
        corpus = [f"{c.title} {c.section} {c.text}" for c in self.chunks]
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2), sublinear_tf=True, stop_words="english"
        )
        self.matrix = self.vectorizer.fit_transform(corpus)

    def _scores(self, query: str):
        return linear_kernel(self.vectorizer.transform([query]), self.matrix).ravel()

    def search(self, query: str, k: int = 3, category: str | None = None) -> list[Hit]:
        """Best chunk per document, highest score first."""
        best: dict[str, Hit] = {}
        for chunk, score in zip(self.chunks, self._scores(query)):
            boosted = float(score) + (CATEGORY_BOOST if category and chunk.category == category else 0.0)
            current = best.get(chunk.doc_id)
            if current is None or boosted > current.score:
                best[chunk.doc_id] = Hit(
                    chunk.doc_id, chunk.title, chunk.category, chunk.section, boosted
                )
        hits = [h for h in best.values() if h.score >= MIN_SCORE]
        return sorted(hits, key=lambda h: h.score, reverse=True)[:k]

    def scenario_for(self, doc_id: str, query: str) -> Chunk | None:
        """The troubleshooting scenario of ``doc_id`` that best matches the query."""
        scores = self._scores(query)
        candidates = [
            (scores[i], chunk)
            for i, chunk in enumerate(self.chunks)
            if chunk.doc_id == doc_id and chunk.steps
        ]
        return max(candidates, key=lambda c: c[0])[1] if candidates else None

    def steps_for(self, doc_id: str, query: str, limit: int = 5) -> list[str]:
        scenario = self.scenario_for(doc_id, query)
        return scenario.steps[:limit] if scenario else []

    def list_articles(self) -> list[dict[str, str]]:
        seen: dict[str, dict[str, str]] = {}
        for c in self.chunks:
            seen.setdefault(c.doc_id, {"id": c.doc_id, "title": c.title, "category": c.category})
        return list(seen.values())
