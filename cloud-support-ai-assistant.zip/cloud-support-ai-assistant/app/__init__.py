"""Cloud Support Copilot - AI-assisted ticket triage for cloud support teams."""

__version__ = "1.0.0"
