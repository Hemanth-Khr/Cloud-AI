"""Mask secrets before text is echoed back, logged or sent to an LLM."""
from __future__ import annotations

import re

_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # AWS access key IDs (long-term AKIA..., temporary ASIA...)
    (re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"), r"\1****************"),
    # key=value style secrets
    (
        re.compile(
            r"(?i)\b(aws_secret_access_key|secret[_-]?access[_-]?key|password|passwd|token|api[_-]?key)"
            r"\s*[=:]\s*\S+"
        ),
        r"\1=REDACTED",
    ),
    # Bearer tokens
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._\-]{16,}"), "Bearer REDACTED"),
]


def redact(text: str) -> str:
    """Return ``text`` with common credential formats masked."""
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text
