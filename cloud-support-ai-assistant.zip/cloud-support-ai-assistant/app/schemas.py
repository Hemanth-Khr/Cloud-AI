"""Pydantic request / response models for the REST API."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class TriageRequest(BaseModel):
    subject: str = Field("", max_length=200, description="Ticket subject line (optional)")
    description: str = Field(..., min_length=10, max_length=10_000)
    logs: Optional[str] = Field(None, max_length=200_000, description="Pasted log excerpt (optional)")
    use_llm: bool = Field(False, description="Polish the reply with Claude if ANTHROPIC_API_KEY is set")


class LogRequest(BaseModel):
    logs: str = Field(..., min_length=1, max_length=200_000)


class Alternative(BaseModel):
    category: str
    confidence: float


class ArticleHit(BaseModel):
    id: str
    title: str
    category: str
    matched_section: str
    score: float


class LogFinding(BaseModel):
    id: str
    severity: str
    category: str
    title: str
    advice: str
    occurrences: int
    example: str


class LogAnalysis(BaseModel):
    findings: list[LogFinding]
    error_line_count: int
    lines_scanned: int


class TriageResponse(BaseModel):
    category: str
    category_label: str
    confidence: float
    alternatives: list[Alternative]
    needs_human_review: bool
    priority: str
    priority_reasons: list[str]
    target_first_response: str
    suggested_articles: list[ArticleHit]
    matched_scenario: Optional[str] = None
    suggested_steps: list[str]
    log_analysis: Optional[LogAnalysis] = None
    draft_reply: str
    reply_source: str
