"""Ticket category classifier: TF-IDF features + Logistic Regression."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from .config import EVAL_CSV, MODEL_PATH, TICKETS_CSV


def build_pipeline() -> Pipeline:
    return Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    ngram_range=(1, 2),
                    lowercase=True,
                    sublinear_tf=True,
                    stop_words="english",
                ),
            ),
            ("clf", LogisticRegression(max_iter=2000, C=5.0)),
        ]
    )


def train(
    csv_path: Path = TICKETS_CSV,
    model_path: Path = MODEL_PATH,
    eval_csv: Path | None = EVAL_CSV,
    seed: int = 42,
) -> dict[str, Any]:
    """Train, evaluate and save the classifier.

    Two evaluations are reported on purpose:

    * ``template_holdout`` - random 20% split of the synthetic data. This is
      optimistic because test rows come from the same templates.
    * ``handwritten_eval`` - separately written, natural-language tickets the
      model never saw. This is the number to trust.
    """
    df = pd.read_csv(csv_path)
    x_train, x_test, y_train, y_test = train_test_split(
        df["text"], df["category"], test_size=0.2, random_state=seed, stratify=df["category"]
    )
    pipe = build_pipeline().fit(x_train, y_train)
    holdout_pred = pipe.predict(x_test)
    metrics: dict[str, Any] = {
        "n_train": int(len(x_train)),
        "n_test": int(len(x_test)),
        "template_holdout_accuracy": float(accuracy_score(y_test, holdout_pred)),
    }

    # Refit on all synthetic data for the production model, then score it on
    # the independent hand-written set.
    pipe = build_pipeline().fit(df["text"], df["category"])
    if eval_csv is not None and Path(eval_csv).exists():
        ev = pd.read_csv(eval_csv)
        ev_pred = pipe.predict(ev["text"])
        metrics["handwritten_eval_accuracy"] = float(accuracy_score(ev["category"], ev_pred))
        metrics["handwritten_eval_n"] = int(len(ev))
        metrics["handwritten_eval_report"] = classification_report(
            ev["category"], ev_pred, output_dict=True, zero_division=0
        )

    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, model_path)
    return metrics


@dataclass
class Prediction:
    label: str
    confidence: float
    alternatives: list[tuple[str, float]]


class TicketClassifier:
    """Loads the saved pipeline (training it on first use if missing)."""

    def __init__(self, model_path: Path = MODEL_PATH, csv_path: Path = TICKETS_CSV):
        if not Path(model_path).exists():
            train(csv_path=csv_path, model_path=model_path)
        self.pipeline: Pipeline = joblib.load(model_path)

    def predict(self, text: str, top_k: int = 3) -> Prediction:
        probs = self.pipeline.predict_proba([text])[0]
        classes = self.pipeline.classes_
        ranked = sorted(zip(classes, probs), key=lambda p: p[1], reverse=True)
        label, confidence = ranked[0]
        return Prediction(
            label=str(label),
            confidence=float(confidence),
            alternatives=[(str(c), float(p)) for c, p in ranked[1:top_k]],
        )
